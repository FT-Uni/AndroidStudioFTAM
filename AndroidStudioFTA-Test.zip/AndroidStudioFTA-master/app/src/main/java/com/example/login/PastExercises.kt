package com.example.login

data class PastExercises(val name: String, val muscleGroup: String, val date: String, val day: String, val weekNumber: Int)
